document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("products").innerHTML = "<p>Loading fashion items...</p>";
});
