const express = require('express');
const app = express();
const port = 4000;

app.use(express.static('frontend'));

app.get('/api/products', (req, res) => {
    res.json([{ id: 1, name: "T-Shirt", price: 25 }, { id: 2, name: "Jeans", price: 40 }]);
});

app.listen(port, () => {
    console.log(`FashionHub backend running at http://localhost:${port}`);
});
